# Derniers orphelins branchés

| Fichier | Branchement |
|---------|-------------|
| `CompaniesTab.jsx` | Re-export → `CommunityTab` (compat) |
| `ProductCard.jsx` | Liste produits dans `ShopDetail` |
| `BackBar.jsx` | `CompanyDetail`, `ShopDetail`, `PrivacyPage` |
| `RichTextComposer.jsx` | Composeur du fil (`FeedTab`) |
| `RichTextRenderer.jsx` | Corps des posts (sans `react-markdown`, rendu léger safe) |

## Copier dans le repo

```
src/components/CompaniesTab.jsx
src/components/CompanyDetail.jsx
src/components/PrivacyPage.jsx
src/components/RichTextRenderer.jsx
src/features/feed/FeedTab.jsx
src/features/shop/components/ShopDetail.jsx
```

(`BackBar`, `ProductCard`, `RichTextComposer` déjà présents — seuls les fichiers qui les **utilisent** changent, plus `RichTextRenderer` réécrit.)

```bash
npm run build
```
